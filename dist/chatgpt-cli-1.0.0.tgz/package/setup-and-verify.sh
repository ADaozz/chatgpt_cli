#!/usr/bin/env bash
# setup-and-verify.sh
#
# 一键准备 ChatGPTCLI 复现环境（WSL2 + Windows Chrome）：
#   1. npm install
#   2. 启动 Chrome（--remote-debugging-port）
#   3. netsh 端口转发（Chrome 147+ 强制绑 localhost，WSL 跨网访问不到）
#   4. 防火墙放行
#   5. 自动轮询 ChatGPT 登录态
#   6. 写 .env + 最终验证
#
# 用法：
#   bash setup-and-verify.sh
#   PORT=9224 bash setup-and-verify.sh

set -euo pipefail

PORT="${PORT:-9224}"
PROFILE_DIR="${PROFILE_DIR:-C:\\chrome-cdp-profile}"
CHROME_WIN="${CHROME_WIN:-C:\\Users\\25129\\AppData\\Local\\Google\\Chrome\\Application\\chrome.exe}"
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

log()  { printf '\033[1;36m[*]\033[0m %s\n' "$*"; }
ok()   { printf '\033[1;32m[OK]\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m[!]\033[0m %s\n' "$*"; }
err()  { printf '\033[1;31m[ERR]\033[0m %s\n' "$*" >&2; }

cd "$PROJECT_DIR"

# ── 0. 代理排除 + 宿主机 IP ──────────────────────────────────────────────────
HOST_IP="$(ip route show default | awk '/default/ {print $3; exit}')"
[[ -n "$HOST_IP" ]] || { err "无法解析 WSL 宿主机 IP"; exit 1; }
BYPASS="${HOST_IP},localhost,127.0.0.1,::1"
export NO_PROXY="$BYPASS"
export no_proxy="$BYPASS"
BROWSER_URL="http://${HOST_IP}:${PORT}"
log "NO_PROXY=${BYPASS}"
ok "BROWSER_URL=${BROWSER_URL}"

# ── 1. 依赖 ───────────────────────────────────────────────────────────────────
log "检查 Node / npm"
command -v node >/dev/null || { err "未找到 node"; exit 1; }
command -v npm  >/dev/null || { err "未找到 npm"; exit 1; }
ok "node $(node -v) / npm $(npm -v)"

if [[ ! -d node_modules ]]; then
  log "npm install"
  npm install
  ok "依赖安装完成"
else
  ok "node_modules 已存在"
fi

# ── 2. 探测 / 启动 Chrome ────────────────────────────────────────────────────
probe_remote() {
  curl -sS --max-time 2 "${BROWSER_URL}/json/version" >/dev/null 2>&1
}

# Chrome 147+ 忽略 --remote-debugging-address，可能绑 127.0.0.1 或 [::1]
# PowerShell 输出带 \r，必须 tr -d 否则 grep 匹配不上
chrome_listening() {
  powershell.exe -Command "netstat -ano | Select-String ':${PORT}.*LISTENING'" 2>/dev/null \
    | tr -d '\r' | grep -qE "(127\.0\.0\.1|\[::1\]|::1):${PORT}"
}

if probe_remote; then
  ok "Chrome 调试端口已就绪"
else
  if chrome_listening; then
    warn "Chrome 已在 localhost:${PORT} 监听，WSL 需要端口转发（步骤 3）"
  else
    warn "Chrome 未启动，正在拉起"

    WIN_PROXY="${CHROME_PROXY:-${HTTPS_PROXY:-${HTTP_PROXY:-}}}"
    PROXY_ARG=""
    if [[ -n "$WIN_PROXY" ]]; then
      log "传递代理给 Chrome: ${WIN_PROXY}"
      PROXY_ARG=",'--proxy-server=${WIN_PROXY}'"
    fi

    powershell.exe -Command "Start-Process '${CHROME_WIN}' -ArgumentList '--remote-debugging-port=${PORT}','--remote-debugging-address=0.0.0.0','--user-data-dir=${PROFILE_DIR}'${PROXY_ARG},'https://chatgpt.com'" 2>/dev/null || true

    log "等待 Chrome 启动（最长 30s）..."
    for i in $(seq 1 30); do
      if chrome_listening; then ok "Chrome 已启动"; break; fi
      sleep 1
      [[ $i -eq 30 ]] && { err "Chrome 未启动。检查路径 $CHROME_WIN"; exit 1; }
    done
  fi

  # ── 3. 端口转发 ────────────────────────────────────────────────────────────
  #    Chrome 147+ 强制绑 localhost（IPv4 或 IPv6 不确定），
  #    WSL2 是独立 vNIC，必须通过 netsh portproxy 把 0.0.0.0 转进去。
  #    同时设置 v4tov4（→127.0.0.1）和 v4tov6（→::1），谁有效算谁。
  if ! probe_remote; then
    log "设置 netsh 端口转发 + 防火墙规则（需要管理员权限 / UAC）"
    powershell.exe -Command "Start-Process powershell -Verb RunAs -ArgumentList '-Command',\
      'netsh interface portproxy delete v4tov4 listenport=${PORT} listenaddress=0.0.0.0 2>\$null;\
       netsh interface portproxy delete v4tov6 listenport=${PORT} listenaddress=0.0.0.0 2>\$null;\
       netsh interface portproxy add v4tov4 listenport=${PORT} listenaddress=0.0.0.0 connectport=${PORT} connectaddress=127.0.0.1;\
       netsh interface portproxy add v4tov6 listenport=${PORT} listenaddress=0.0.0.0 connectport=${PORT} connectaddress=::1;\
       Remove-NetFirewallRule -DisplayName \"Chrome CDP ${PORT}\" -ErrorAction SilentlyContinue;\
       New-NetFirewallRule -DisplayName \"Chrome CDP ${PORT}\" -Direction Inbound -Protocol TCP -LocalPort ${PORT} -Action Allow | Out-Null;\
       Write-Host \"portproxy + firewall done\"'" 2>/dev/null || true

    log "等待端口转发生效（最长 15s）..."
    for i in $(seq 1 15); do
      if probe_remote; then ok "端口转发生效"; break; fi
      sleep 1
      [[ $i -eq 15 ]] && { err "端口转发未生效。确认 UAC 弹窗已点"是"。"; exit 1; }
    done
  fi
fi

# ── 4. 等待 ChatGPT 登录态 ───────────────────────────────────────────────────
log "检测 ChatGPT 登录态..."
for i in $(seq 1 120); do
  logged_in="$(CHATGPT_BROWSER_URL="$BROWSER_URL" node -e '
    const p = require("puppeteer-core");
    (async () => {
      const b = await p.connect({ browserURL: process.env.CHATGPT_BROWSER_URL, defaultViewport: null });
      try {
        const pages = await b.pages();
        const page = pages.find(x => x.url().includes("chatgpt.com")) || pages[0];
        if (!page) { console.log("0"); return; }
        const ok = await page.evaluate(async () => {
          try { const r = await fetch("/api/auth/session"); const j = await r.json(); return Boolean(j && j.accessToken); }
          catch { return false; }
        });
        console.log(ok ? "1" : "0");
      } finally { await b.disconnect().catch(()=>{}); }
    })().catch(() => console.log("0"));
  ' 2>/dev/null || echo 0)"

  if [[ "$logged_in" == "1" ]]; then
    ok "ChatGPT 登录态已确认"
    break
  fi
  [[ $i -eq 1 ]] && warn "未检测到登录态，请在 Chrome 窗口登录 chatgpt.com ..."
  sleep 5
  [[ $i -eq 120 ]] && { err "10 分钟超时"; exit 1; }
done

# ── 5. 写入 .env ─────────────────────────────────────────────────────────────
log "写入 .env"
{
  grep -v '^CHATGPT_BROWSER_URL=' .env 2>/dev/null || true
  echo "CHATGPT_BROWSER_URL=${BROWSER_URL}"
} > .env.tmp && mv .env.tmp .env
ok ".env → CHATGPT_BROWSER_URL=${BROWSER_URL}"

# ── 6. 最终验证 ──────────────────────────────────────────────────────────────
log "最终验证"
CHATGPT_BROWSER_URL="$BROWSER_URL" node -e '
const { ChatGPTClient } = require("./index");
(async () => {
  const c = await ChatGPTClient.create(process.env.CHATGPT_BROWSER_URL);
  try {
    const url = await c._page.url();
    const title = await c._page.title();
    const loggedIn = await c._page.evaluate(async () => {
      try { const r = await fetch("/api/auth/session"); const j = await r.json(); return Boolean(j && j.accessToken); }
      catch { return false; }
    });
    console.log(JSON.stringify({ url, title, loggedIn }, null, 2));
    if (!loggedIn) { console.error("登录态丢失"); process.exit(2); }
  } finally { await c.disconnect().catch(() => {}); }
})().catch(e => { console.error(e.message); process.exit(1); });
'

ok "全部通过 ✅"
echo ""
echo "  接下来可以运行:"
echo "    NO_PROXY=${BYPASS} CHATGPT_BROWSER_URL=${BROWSER_URL} node example.js"
echo ""
